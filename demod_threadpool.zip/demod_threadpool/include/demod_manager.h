#ifndef DEMOD_MANAGER_H
#define DEMOD_MANAGER_H

#include <array>
#include <mutex>
#include <fstream>
#include "demod_api.h"

constexpr size_t NUM_CHANNELS = 256;

class DemodManager {
public:
    DemodManager();
    ~DemodManager();
    
    bool init();
    void processData(size_t channelStart, size_t channelEnd, const uint8_t* data, size_t dataSize);
    uint64_t getTotalProcessed() const { return totalProcessed_.load(); }

private:
    static void outputCallback(struct DemodOutput* output, void* userData);
    
    std::array<void*, NUM_CHANNELS> handles_;
    std::array<std::ofstream, NUM_CHANNELS> outputFiles_;
    std::array<std::mutex, NUM_CHANNELS> fileMutexes_;
    std::atomic<uint64_t> totalProcessed_;
};

#endif
