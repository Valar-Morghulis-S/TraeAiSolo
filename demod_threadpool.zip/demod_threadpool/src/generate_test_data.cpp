#include <iostream>
#include <fstream>
#include <vector>
#include <random>

int main(int argc, char* argv[]) {
    if (argc < 3) {
        std::cerr << "Usage: " << argv[0] << " <output.iq> <size_mb>" << std::endl;
        return 1;
    }
    
    size_t sizeMB = std::stoul(argv[2]);
    size_t sizeBytes = sizeMB * 1024 * 1024;
    
    std::ofstream out(argv[1], std::ios::binary);
    if (!out) {
        std::cerr << "Failed to open output file" << std::endl;
        return 1;
    }
    
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int16_t> dist(-32768, 32767);
    
    std::vector<uint8_t> buf(1024 * 1024);
    size_t written = 0;
    
    while (written < sizeBytes) {
        size_t chunk = std::min(buf.size(), sizeBytes - written);
        for (size_t i = 0; i < chunk; i += 4) {
            int16_t iq[2] = {dist(gen), dist(gen)};
            buf[i] = iq[0] >> 8;
            buf[i + 1] = iq[0] & 0xFF;
            buf[i + 2] = iq[1] >> 8;
            buf[i + 3] = iq[1] & 0xFF;
        }
        out.write(reinterpret_cast<char*>(buf.data()), chunk);
        written += chunk;
    }
    
    std::cout << "Generated " << sizeMB << " MB test data" << std::endl;
    return 0;
}
