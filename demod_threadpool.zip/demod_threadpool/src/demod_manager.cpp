#include "demod_manager.h"
#include <iostream>

struct CallbackContext {
    std::ofstream* file;
    std::mutex* mutex;
};

DemodManager::DemodManager() : totalProcessed_(0) {
    handles_.fill(nullptr);
}

DemodManager::~DemodManager() {
    for (size_t i = 0; i < NUM_CHANNELS; ++i) {
        if (handles_[i]) {
            destroy(handles_[i]);
        }
        if (outputFiles_[i].is_open()) {
            outputFiles_[i].close();
        }
    }
}

bool DemodManager::init() {
    for (size_t ch = 0; ch < NUM_CHANNELS; ++ch) {
        handles_[ch] = create();
        if (!handles_[ch]) {
            std::cerr << "Failed to create demod for channel " << ch << std::endl;
            return false;
        }
        
        uint32_t channelId = static_cast<uint32_t>(ch);
        setParam(handles_[ch], 0, &channelId);
        
        std::string filename = std::to_string(ch) + "_output.bin";
        outputFiles_[ch].open(filename, std::ios::binary);
        if (!outputFiles_[ch]) {
            std::cerr << "Failed to open output file for channel " << ch << std::endl;
            return false;
        }
        
        CallbackContext* ctx = new CallbackContext{&outputFiles_[ch], &fileMutexes_[ch]};
        setDataCallback(handles_[ch], outputCallback, ctx);
    }
    std::cout << "Initialized " << NUM_CHANNELS << " demod instances" << std::endl;
    return true;
}

void DemodManager::outputCallback(struct DemodOutput* output, void* userData) {
    CallbackContext* ctx = static_cast<CallbackContext*>(userData);
    if (ctx && ctx->file && ctx->file->is_open()) {
        std::lock_guard<std::mutex> lock(*ctx->mutex);
        ctx->file->write(reinterpret_cast<const char*>(output->data), output->dataLen);
    }
}

void DemodManager::processData(size_t channelStart, size_t channelEnd, const uint8_t* data, size_t dataSize) {
    const size_t samplesPerBlock = 1024;
    
    for (size_t ch = channelStart; ch < channelEnd; ++ch) {
        size_t offset = 0;
        while (offset + 4 <= dataSize) {
            size_t remaining = (dataSize - offset) / 4;
            size_t samples = std::min(remaining, samplesPerBlock);
            
            std::vector<Demod_16sc> demodData(samples);
            for (size_t i = 0; i < samples; ++i) {
                size_t idx = offset + i * 4;
                demodData[i].i = static_cast<short>((data[idx] << 8) | data[idx + 1]);
                demodData[i].q = static_cast<short>((data[idx + 2] << 8) | data[idx + 3]);
            }
            
            Demod_16sc(handles_[ch], demodData.data(), static_cast<uint32_t>(samples));
            totalProcessed_ += samples;
            offset += samples * 4;
        }
    }
}
