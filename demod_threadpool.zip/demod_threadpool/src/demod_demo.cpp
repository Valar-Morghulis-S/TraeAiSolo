#include <iostream>
#include <fstream>
#include <vector>
#include <chrono>
#include "thread_pool.h"
#include "demod_manager.h"

constexpr size_t NUM_THREADS = 8;

void processTask(size_t threadId, const uint8_t* data, size_t dataSize, DemodManager& manager) {
    size_t channelsPerThread = NUM_CHANNELS / NUM_THREADS;
    size_t startCh = threadId * channelsPerThread;
    size_t endCh = (threadId == NUM_THREADS - 1) ? NUM_CHANNELS : (threadId + 1) * channelsPerThread;
    
    manager.processData(startCh, endCh, data, dataSize);
    std::cout << "Thread " << threadId << " processed channels " << startCh << "-" << (endCh - 1) << std::endl;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <input_file.iq>" << std::endl;
        return 1;
    }
    
    std::ifstream inputFile(argv[1], std::ios::binary);
    if (!inputFile) {
        std::cerr << "Failed to open input file" << std::endl;
        return 1;
    }
    
    inputFile.seekg(0, std::ios::end);
    size_t fileSize = static_cast<size_t>(inputFile.tellg());
    inputFile.seekg(0, std::ios::beg);
    
    std::vector<uint8_t> fileData(fileSize);
    inputFile.read(reinterpret_cast<char*>(fileData.data()), fileSize);
    inputFile.close();
    
    std::cout << "File size: " << fileSize << " bytes" << std::endl;
    
    DemodManager manager;
    if (!manager.init()) {
        std::cerr << "Failed to initialize demod manager" << std::endl;
        return 1;
    }
    
    ThreadPool pool(NUM_THREADS);
    auto startTime = std::chrono::high_resolution_clock::now();
    
    for (size_t i = 0; i < NUM_THREADS; ++i) {
        pool.submit(processTask, i, fileData.data(), fileSize, std::ref(manager));
    }
    
    pool.waitAll();
    
    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
    
    std::cout << "\nProcessing complete!" << std::endl;
    std::cout << "Total samples processed: " << manager.getTotalProcessed() << std::endl;
    std::cout << "Time: " << duration.count() << " ms" << std::endl;
    
    if (duration.count() > 0) {
        double throughput = static_cast<double>(fileSize * NUM_CHANNELS) / (1024.0 * 1024.0) / (duration.count() / 1000.0);
        std::cout << "Throughput: " << throughput << " MB/s" << std::endl;
    }
    
    return 0;
}
