#include "thread_pool.h"

ThreadPool::ThreadPool(size_t numThreads) : stop_(false), activeTasks_(0) {
    workers_.reserve(numThreads);
    for (size_t i = 0; i < numThreads; ++i) {
        workers_.emplace_back([this, i]() { workerLoop(i); });
    }
}

ThreadPool::~ThreadPool() { shutdown(); }

void ThreadPool::workerLoop(size_t) {
    while (true) {
        std::function<void()> task;
        {
            std::unique_lock<std::mutex> lock(queueMutex_);
            condition_.wait(lock, [this]() { return stop_ || !tasks_.empty(); });
            if (stop_ && tasks_.empty()) return;
            task = std::move(tasks_.front());
            tasks_.pop();
            activeTasks_++;
        }
        task();
        activeTasks_--;
    }
}

void ThreadPool::waitAll() {
    while (true) {
        {
            std::unique_lock<std::mutex> lock(queueMutex_);
            if (tasks_.empty() && activeTasks_ == 0) return;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}

void ThreadPool::shutdown() {
    {
        std::unique_lock<std::mutex> lock(queueMutex_);
        stop_ = true;
    }
    condition_.notify_all();
    for (std::thread& w : workers_) {
        if (w.joinable()) w.join();
    }
}
