#include <iostream>
#include <csignal>
#include <atomic>
#include "ddc_processor.h"
#include "shm_simulator.h"

std::atomic<bool> g_running(true);

void signalHandler(int signal) {
    std::cout << "Received signal " << signal << ", stopping..." << std::endl;
    g_running = false;
}

int main(int argc, char* argv[]) {
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);
    
    size_t numFrames = 10000;
    if (argc > 1) {
        numFrames = std::stoull(argv[1]);
    }
    
    std::cout << "=== DDC Demodulator with Thread Pool ===" << std::endl;
    std::cout << "Frames to simulate: " << numFrames << std::endl;
    std::cout << std::endl;
    
    DDCProcessor processor;
    if (!processor.init()) {
        std::cerr << "Failed to initialize DDC processor" << std::endl;
        return 1;
    }
    
    SHMSimulator simulator;
    simulator.setWriteCallback([&processor](const uint8_t* data, size_t size) {
        processor.simulateShmWrite(data, size);
    });
    
    processor.start();
    simulator.startSimulation(numFrames);
    
    while (g_running) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    
    simulator.stop();
    processor.stop();
    
    std::cout << "Program exiting" << std::endl;
    return 0;
}
