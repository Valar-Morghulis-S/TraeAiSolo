#include "ddc_processor.h"
#include <iostream>
#include <chrono>

DDCProcessor::DDCProcessor()
    : running_(false) {
}

DDCProcessor::~DDCProcessor() {
    stop();
}

bool DDCProcessor::init() {
    ringBuffer_ = std::make_unique<RingBuffer>();
    threadPool_ = std::make_unique<ThreadPool>(8);
    demodManager_ = std::make_unique<DemodManager>();
    
    if (!demodManager_->init()) {
        return false;
    }
    
    return true;
}

void DDCProcessor::start() {
    if (running_) {
        return;
    }
    
    running_ = true;
    workerThread_ = std::thread(&DDCProcessor::workerLoop, this);
    std::cout << "DDCProcessor started" << std::endl;
}

void DDCProcessor::stop() {
    if (!running_) {
        return;
    }
    
    running_ = false;
    
    if (workerThread_.joinable()) {
        workerThread_.join();
    }
    
    threadPool_->waitAll();
    std::cout << "DDCProcessor stopped" << std::endl;
    std::cout << "Total processed samples: " << demodManager_->getTotalProcessed() << std::endl;
}

void DDCProcessor::simulateShmWrite(const uint8_t* data, size_t size) {
    ringBuffer_->push(data, size);
}

void DDCProcessor::workerLoop() {
    DDCFrame frame;
    
    while (running_) {
        if (ringBuffer_->pop(frame)) {
            processDDCFrame(frame);
        } else {
            std::this_thread::sleep_for(std::chrono::microseconds(100));
        }
    }
}

void DDCProcessor::processDDCFrame(DDCFrame& frame) {
    if (frame.channelId >= NUM_CHANNELS) {
        return;
    }
    
    threadPool_->submit([this, frame]() {
        demodManager_->processFrame(frame.channelId, frame.data, frame.dataSize);
    });
}
