#include "shm_simulator.h"
#include <cstring>
#include <random>
#include <iostream>

SHMSimulator::SHMSimulator()
    : running_(false) {
}

SHMSimulator::~SHMSimulator() {
    stop();
}

void SHMSimulator::setWriteCallback(WriteCallback callback) {
    writeCallback_ = callback;
}

void SHMSimulator::startSimulation(size_t numFrames) {
    if (running_) {
        return;
    }
    
    running_ = true;
    simThread_ = std::thread(&SHMSimulator::simulateLoop, this, numFrames);
}

void SHMSimulator::stop() {
    if (!running_) {
        return;
    }
    
    running_ = false;
    
    if (simThread_.joinable()) {
        simThread_.join();
    }
}

void SHMSimulator::generateDDCFrame(uint8_t* buffer, size_t& size, uint8_t cpuId, uint8_t channelId) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int16_t> dist(-32768, 32767);
    
    memset(buffer, 0, DDC_FRAME_SIZE);
    
    buffer[8] = cpuId;
    buffer[9] = channelId;
    
    size_t payloadOffset = 128;
    size_t payloadSize = 2048;
    
    for (size_t i = 0; i < payloadSize; i += 4) {
        int16_t iq[2] = {dist(gen), dist(gen)};
        buffer[payloadOffset + i] = iq[0] >> 8;
        buffer[payloadOffset + i + 1] = iq[0] & 0xFF;
        buffer[payloadOffset + i + 2] = iq[1] >> 8;
        buffer[payloadOffset + i + 3] = iq[1] & 0xFF;
    }
    
    size = DDC_FRAME_SIZE;
}

void SHMSimulator::simulateLoop(size_t numFrames) {
    std::vector<uint8_t> frameBuffer(DDC_FRAME_SIZE);
    size_t frameSize;
    uint8_t channelId = 0;
    
    std::cout << "SHM simulator starting: " << numFrames << " frames" << std::endl;
    
    for (size_t i = 0; i < numFrames && running_; ++i) {
        uint8_t cpuId = static_cast<uint8_t>(i % 2);
        channelId = static_cast<uint8_t>(i % NUM_CHANNELS);
        
        generateDDCFrame(frameBuffer.data(), frameSize, cpuId, channelId);
        
        if (writeCallback_) {
            writeCallback_(frameBuffer.data(), frameSize);
        }
        
        std::this_thread::sleep_for(std::chrono::microseconds(100));
        
        if (i % 1000 == 0) {
            std::cout << "Generated " << i << " frames" << std::endl;
        }
    }
    
    std::cout << "SHM simulator completed" << std::endl;
}
