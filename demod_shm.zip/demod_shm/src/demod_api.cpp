#include "demod_api.h"
#include <iostream>
#include <cstring>

struct DemodContext {
    DemodDataCallback callback;
    void* userData;
    uint32_t channelId;
};

void* create(void) {
    DemodContext* ctx = new DemodContext();
    ctx->callback = nullptr;
    ctx->userData = nullptr;
    ctx->channelId = 0;
    return ctx;
}

int setParam(void* handle, int paramType, void* paramValue) {
    if (!handle) return -1;
    DemodContext* ctx = static_cast<DemodContext*>(handle);
    
    if (paramType == 0 && paramValue) {
        ctx->channelId = *static_cast<uint32_t*>(paramValue);
    }
    
    return 0;
}

int setDataCallback(void* handle, DemodDataCallback callback, void* userData) {
    if (!handle) return -1;
    DemodContext* ctx = static_cast<DemodContext*>(handle);
    ctx->callback = callback;
    ctx->userData = userData;
    return 0;
}

int Demod_16sc(void* handle, struct Demod_16sc* data, uint32_t len) {
    if (!handle || !data || len == 0) return -1;
    DemodContext* ctx = static_cast<DemodContext*>(handle);
    
    if (ctx->callback) {
        struct DemodOutput output;
        output.dataLen = len * 2;
        output.data = new uint8_t[output.dataLen];
        
        for (uint32_t i = 0; i < len; i++) {
            uint8_t* ptr = output.data + i * 2;
            ptr[0] = static_cast<uint8_t>(data[i].i & 0xFF);
            ptr[1] = static_cast<uint8_t>(data[i].q & 0xFF);
        }
        
        output.channelId = ctx->channelId;
        
        ctx->callback(&output, ctx->userData);
        
        delete[] output.data;
    }
    
    return 0;
}

void destroy(void* handle) {
    if (handle) {
        delete static_cast<DemodContext*>(handle);
    }
}
