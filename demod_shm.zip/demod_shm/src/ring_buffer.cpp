#include "ring_buffer.h"
#include <cstring>
#include <iostream>

RingBuffer::RingBuffer()
    : writeIndex_(0), readIndex_(0) {
    
    buffer_.reserve(RING_BUFFER_SIZE);
    for (size_t i = 0; i < RING_BUFFER_SIZE; ++i) {
        buffer_.emplace_back(std::make_unique<DDCFrame>());
    }
    
    std::cout << "RingBuffer initialized with " << RING_BUFFER_SIZE << " slots" << std::endl;
}

RingBuffer::~RingBuffer() {
    std::cout << "RingBuffer destroyed" << std::endl;
}

bool RingBuffer::push(const uint8_t* data, size_t size) {
    size_t nextWrite = (writeIndex_ + 1) % RING_BUFFER_SIZE;
    
    if (nextWrite == readIndex_) {
        return false;
    }
    
    DDCFrame* frame = buffer_[writeIndex_].get();
    size_t copySize = std::min(size, DDC_FRAME_SIZE);
    memcpy(frame->data, data, copySize);
    frame->dataSize = copySize;
    
    if (copySize >= 10) {
        frame->cpuId = data[8];
        frame->channelId = data[9];
    } else {
        frame->cpuId = 0;
        frame->channelId = 0;
    }
    
    writeIndex_ = nextWrite;
    return true;
}

bool RingBuffer::pop(DDCFrame& frame) {
    if (readIndex_ == writeIndex_) {
        return false;
    }
    
    DDCFrame* srcFrame = buffer_[readIndex_].get();
    memcpy(frame.data, srcFrame->data, srcFrame->dataSize);
    frame.dataSize = srcFrame->dataSize;
    frame.cpuId = srcFrame->cpuId;
    frame.channelId = srcFrame->channelId;
    
    readIndex_ = (readIndex_ + 1) % RING_BUFFER_SIZE;
    return true;
}

bool RingBuffer::isEmpty() const {
    return readIndex_ == writeIndex_;
}

bool RingBuffer::isFull() const {
    size_t nextWrite = (writeIndex_ + 1) % RING_BUFFER_SIZE;
    return nextWrite == readIndex_;
}

size_t RingBuffer::size() const {
    if (writeIndex_ >= readIndex_) {
        return writeIndex_ - readIndex_;
    } else {
        return (RING_BUFFER_SIZE - readIndex_) + writeIndex_;
    }
}
