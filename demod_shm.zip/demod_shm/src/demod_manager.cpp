#include "demod_manager.h"
#include <iostream>
#include <cstring>

DemodManager::DemodManager()
    : totalProcessed_(0) {
    
    handles_.fill(nullptr);
    callbackContexts_.fill(nullptr);
}

DemodManager::~DemodManager() {
    for (size_t i = 0; i < NUM_CHANNELS; ++i) {
        if (handles_[i]) {
            destroy(handles_[i]);
        }
        if (callbackContexts_[i]) {
            delete callbackContexts_[i];
        }
        if (outputFiles_[i].is_open()) {
            outputFiles_[i].close();
        }
    }
    std::cout << "DemodManager cleaned up" << std::endl;
}

bool DemodManager::init() {
    for (size_t ch = 0; ch < NUM_CHANNELS; ++ch) {
        handles_[ch] = create();
        if (!handles_[ch]) {
            std::cerr << "Failed to create demod for channel " << ch << std::endl;
            return false;
        }
        
        uint32_t channelId = static_cast<uint32_t>(ch);
        setParam(handles_[ch], 0, &channelId);
        
        std::string filename = "channel_" + std::to_string(ch) + "_output.bin";
        outputFiles_[ch].open(filename, std::ios::binary);
        if (!outputFiles_[ch]) {
            std::cerr << "Failed to open output file for channel " << ch << std::endl;
            return false;
        }
        
        callbackContexts_[ch] = new CallbackContext{&outputFiles_[ch], &fileMutexes_[ch]};
        setDataCallback(handles_[ch], outputCallback, callbackContexts_[ch]);
    }
    
    std::cout << "Initialized " << NUM_CHANNELS << " demod instances successfully" << std::endl;
    return true;
}

void DemodManager::outputCallback(struct DemodOutput* output, void* userData) {
    CallbackContext* ctx = static_cast<CallbackContext*>(userData);
    if (ctx && ctx->file && ctx->file->is_open()) {
        std::lock_guard<std::mutex> lock(*ctx->mutex);
        ctx->file->write(reinterpret_cast<const char*>(output->data), output->dataLen);
    }
}

void DemodManager::processFrame(uint8_t channelId, const uint8_t* data, size_t dataSize) {
    if (channelId >= NUM_CHANNELS) {
        return;
    }
    
    void* handle = handles_[channelId];
    if (!handle) {
        return;
    }
    
    const size_t HEADER_SIZE = 128;
    if (dataSize < HEADER_SIZE) {
        return;
    }
    
    const uint8_t* payload = data + HEADER_SIZE;
    size_t payloadSize = dataSize - HEADER_SIZE;
    
    const size_t samplesPerBlock = 1024;
    size_t offset = 0;
    
    while (offset + 4 <= payloadSize) {
        size_t remaining = (payloadSize - offset) / 4;
        size_t samples = std::min(remaining, samplesPerBlock);
        
        std::vector<Demod_16sc> demodData(samples);
        for (size_t i = 0; i < samples; ++i) {
            size_t idx = offset + i * 4;
            demodData[i].i = static_cast<short>((payload[idx] << 8) | payload[idx + 1]);
            demodData[i].q = static_cast<short>((payload[idx + 2] << 8) | payload[idx + 3]);
        }
        
        Demod_16sc(handle, demodData.data(), static_cast<uint32_t>(samples));
        totalProcessed_ += samples;
        offset += samples * 4;
    }
}
