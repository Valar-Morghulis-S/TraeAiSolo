# DDC Demodulator with Thread Pool

## 项目简介

这是一个基于Linux C++的DDC(数字下变频)解调库项目，使用线程池处理256路DDC数据，通过共享内存方式接收数据。

## 项目结构

```
demod_shm/
├── CMakeLists.txt              # CMake构建配置
├── include/                    # 头文件
│   ├── demod_api.h             # 解调库接口定义
│   ├── demod_manager.h         # 解调器管理器
│   ├── ddc_processor.h         # DDC数据处理器
│   ├── ring_buffer.h           # 环形缓冲区
│   ├── shm_simulator.h         # 共享内存模拟器
│   └── thread_pool.h           # 线程池
├── src/                        # 源文件
│   ├── demod_api.cpp           # 解调库实现(模拟)
│   ├── demod_manager.cpp       # 解调器管理器实现
│   ├── ddc_processor.cpp       # DDC数据处理器实现
│   ├── ring_buffer.cpp         # 环形缓冲区实现
│   ├── shm_simulator.cpp       # 共享内存模拟器实现
│   ├── thread_pool.cpp         # 线程池实现
│   └── main.cpp                # 主程序
└── README.md                   # 本文件
```

## 核心功能

### 1. 共享内存环形缓冲区 (`RingBuffer`)
- 无锁原子操作读写
- 支持1024帧的缓冲区容量
- 单帧大小: 128字节头 + 2048字节数据 = 2176字节

### 2. DDC数据帧解析
- 从数据帧中提取CPUID (第9字节, 索引8)
- 从数据帧中提取ChannelId (第10字节, 索引9)
- 支持256路DDC通道

### 3. 线程池处理 (`ThreadPool`)
- 8个工作线程
- 任务队列管理
- 动态负载均衡

### 4. 解调器管理 (`DemodManager`)
- 创建256个解调器实例
- 按通道ID路由数据
- 回调输出数据到文件

### 5. 共享内存模拟 (`SHMSimulator`)
- 生成模拟DDC数据帧
- 支持指定帧数的模拟
- 可配置发送间隔

## 编译和运行

### 编译

```bash
cd demod_shm
mkdir build && cd build
cmake ..
make
```

### 运行

```bash
# 运行默认参数(10000帧)
./demod_shm_demo

# 运行指定帧数
./demod_shm_demo 50000
```

### 停止程序

按 `Ctrl+C` 可以安全停止程序。

## 数据流程

```
┌───────────────┐
│ SHM Simulator │  生成模拟数据(或实际共享内存)
└───────┬───────┘
        │
        ▼
┌───────────────────┐
│  RingBuffer       │  环形缓冲区(1024帧)
└───────┬───────────┘
        │
        ▼
┌───────────────────┐
│  DDCWorker        │  从缓冲区读取数据
└───────┬───────────┘
        │
        ▼
┌───────────────────┐
│  ThreadPool(8)    │  8个工作线程
└───────┬───────────┘
        │
        ▼
┌───────────────────┐
│  DemodManager     │  256个解调器实例
│  (按ChannelId)    │
└───────┬───────────┘
        │
        ▼
┌───────────────────┐
│  Output Files     │  每通道一个输出文件
│  channel_*.bin    │
└───────────────────┘
```

## 接口说明

### 解调库接口 (`demod_api.h`)

```c++
// 创建解调器实例
void* create();

// 设置参数
int setParam(void* handle, int paramType, void* paramValue);

// 注册回调函数
int setDataCallback(void* handle, DemodDataCallback callback, void* userData);

// 输入I/Q数据
int Demod_16sc(void* handle, struct Demod_16sc* data, uint32_t len);

// 销毁解调器实例
void destroy(void* handle);
```

### 数据结构

```c++
// I/Q数据结构
struct Demod_16sc {
    short i;
    short q;
};

// 解调输出结构
struct DemodOutput {
    uint8_t* data;
    uint32_t dataLen;
    uint32_t channelId;
};

// DDC帧结构
struct DDCFrame {
    uint8_t data[DDC_FRAME_SIZE];  // 完整数据(含头)
    size_t dataSize;               // 数据大小
    uint8_t cpuId;                 // CPU ID(第9字节)
    uint8_t channelId;             // 通道ID(第10字节)
};
```

## 性能特点

1. **资源优化**: 使用8线程处理256路，避免创建256个线程
2. **无锁缓冲**: 环形缓冲区采用原子操作，减少锁竞争
3. **内存效率**: 预分配缓冲区，避免频繁内存分配
4. **文件安全**: 每通道独立互斥锁，保证线程安全

## 输出文件

程序运行后将生成256个输出文件:
- `channel_0_output.bin` 到 `channel_255_output.bin`

每个文件包含对应通道的解调输出数据。

## 实际应用场景替换

将共享内存模拟器替换为实际的共享内存读取代码:

```c++
// 替换SHMSimulator，实际读取共享内存
class RealSHMReader {
public:
    void init() {
        // 连接到实际共享内存
    }
    
    void run(DDCProcessor& processor) {
        while (running) {
            // 从实际共享内存读取数据
            uint8_t* data = read_from_shm();
            size_t size = get_shm_data_size();
            
            // 提交到处理器
            processor.simulateShmWrite(data, size);
        }
    }
};
```
