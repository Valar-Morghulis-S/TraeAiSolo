#ifndef RING_BUFFER_H
#define RING_BUFFER_H

#include <cstdint>
#include <atomic>
#include <vector>
#include <memory>

constexpr size_t DDC_FRAME_SIZE = 128 + 2048;  // 128头 + 2048数据
constexpr size_t RING_BUFFER_SIZE = 1024;       // 1024帧

struct DDCFrame {
    uint8_t data[DDC_FRAME_SIZE];
    size_t dataSize;
    uint8_t cpuId;
    uint8_t channelId;
};

class RingBuffer {
public:
    RingBuffer();
    ~RingBuffer();
    
    bool push(const uint8_t* data, size_t size);
    bool pop(DDCFrame& frame);
    bool isEmpty() const;
    bool isFull() const;
    size_t size() const;

private:
    std::atomic<size_t> writeIndex_;
    std::atomic<size_t> readIndex_;
    std::vector<std::unique_ptr<DDCFrame>> buffer_;
};

#endif
