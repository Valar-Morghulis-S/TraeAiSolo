#ifndef DDC_PROCESSOR_H
#define DDC_PROCESSOR_H

#include <memory>
#include "ring_buffer.h"
#include "thread_pool.h"
#include "demod_manager.h"

class DDCProcessor {
public:
    DDCProcessor();
    ~DDCProcessor();
    
    bool init();
    void start();
    void stop();
    
    void simulateShmWrite(const uint8_t* data, size_t size);

private:
    void workerLoop();
    void processDDCFrame(DDCFrame& frame);
    
    std::unique_ptr<RingBuffer> ringBuffer_;
    std::unique_ptr<ThreadPool> threadPool_;
    std::unique_ptr<DemodManager> demodManager_;
    
    std::atomic<bool> running_;
    std::thread workerThread_;
};

#endif
