#ifndef DEMOD_MANAGER_H
#define DEMOD_MANAGER_H

#include <array>
#include <mutex>
#include <fstream>
#include <atomic>
#include "demod_api.h"

constexpr size_t NUM_CHANNELS = 256;

struct CallbackContext {
    std::ofstream* file;
    std::mutex* mutex;
};

class DemodManager {
public:
    DemodManager();
    ~DemodManager();
    
    bool init();
    void processFrame(uint8_t channelId, const uint8_t* data, size_t dataSize);
    uint64_t getTotalProcessed() const { return totalProcessed_.load(); }

private:
    static void outputCallback(struct DemodOutput* output, void* userData);
    
    std::array<void*, NUM_CHANNELS> handles_;
    std::array<std::ofstream, NUM_CHANNELS> outputFiles_;
    std::array<std::mutex, NUM_CHANNELS> fileMutexes_;
    std::array<CallbackContext*, NUM_CHANNELS> callbackContexts_;
    std::atomic<uint64_t> totalProcessed_;
};

#endif
