#ifndef DEMOD_API_H
#define DEMOD_API_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

struct Demod_16sc {
    short i;
    short q;
};

struct DemodOutput {
    uint8_t *data;
    uint32_t dataLen;
    uint32_t channelId;
};

typedef void (*DemodDataCallback)(struct DemodOutput* output, void* userData);

void* create(void);
int setParam(void* handle, int paramType, void* paramValue);
int setDataCallback(void* handle, DemodDataCallback callback, void* userData);
int Demod_16sc(void* handle, struct Demod_16sc* data, uint32_t len);
void destroy(void* handle);

#ifdef __cplusplus
}
#endif

#endif
