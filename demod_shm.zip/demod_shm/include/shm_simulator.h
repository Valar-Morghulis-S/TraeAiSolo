#ifndef SHM_SIMULATOR_H
#define SHM_SIMULATOR_H

#include <cstdint>
#include <vector>
#include <thread>
#include <atomic>
#include <functional>
#include "ring_buffer.h"

constexpr size_t NUM_CHANNELS = 256;

using WriteCallback = std::function<void(const uint8_t*, size_t)>;

class SHMSimulator {
public:
    SHMSimulator();
    ~SHMSimulator();
    
    void setWriteCallback(WriteCallback callback);
    void startSimulation(size_t numFrames);
    void stop();
    
    void generateDDCFrame(uint8_t* buffer, size_t& size, uint8_t cpuId, uint8_t channelId);

private:
    void simulateLoop(size_t numFrames);
    
    WriteCallback writeCallback_;
    std::thread simThread_;
    std::atomic<bool> running_;
};

#endif
